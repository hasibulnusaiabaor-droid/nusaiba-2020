import { create } from 'zustand';
import { Video } from '@/types';

interface VideoStore {
  videos: Video[];
  currentVideo: Video | null;
  isLoading: boolean;
  error: string | null;
  fetchVideos: () => Promise<void>;
  likeVideo: (videoId: string) => void;
  shareVideo: (videoId: string) => void;
  uploadVideo: (videoData: { title: string; description: string; file: File }) => Promise<void>;
}

// Mock video data
const mockVideos: Video[] = [
  {
    id: '1',
    userId: '1',
    user: {
      id: '1',
      username: 'creator1',
      name: 'Amazing Creator',
      email: 'creator1@example.com',
      profilePicture: 'https://images.unsplash.com/photo-1494790108755-2616b332c6a8?w=50&h=50&fit=crop&crop=face',
      gender: 'female',
      isVerified: true,
      isPrivate: false,
      followers: 10500,
      following: 234,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    title: 'Amazing Dance Performance',
    description: 'Check out this incredible dance routine! 💃✨',
    url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400&h=300&fit=crop',
    duration: 120,
    views: 15420,
    likes: 1240,
    comments: 89,
    shares: 156,
    isShort: true,
    hashtags: ['dance', 'performance', 'viral'],
    createdAt: new Date(Date.now() - 3600000),
    updatedAt: new Date(),
  },
  {
    id: '2',
    userId: '2',
    user: {
      id: '2',
      username: 'techguru',
      name: 'Tech Guru',
      email: 'tech@example.com',
      profilePicture: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop&crop=face',
      gender: 'male',
      isVerified: true,
      isPrivate: false,
      followers: 45600,
      following: 567,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    title: 'AI Revolution in 2024',
    description: 'Exploring the latest AI trends and how they will change our world',
    url: 'https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_2mb.mp4',
    thumbnailUrl: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&h=300&fit=crop',
    duration: 480,
    views: 89320,
    likes: 3450,
    comments: 234,
    shares: 890,
    isShort: false,
    hashtags: ['ai', 'technology', 'future'],
    createdAt: new Date(Date.now() - 7200000),
    updatedAt: new Date(),
  },
];

export const useVideos = create<VideoStore>((set, get) => ({
  videos: [],
  currentVideo: null,
  isLoading: false,
  error: null,

  fetchVideos: async () => {
    set({ isLoading: true, error: null });
    try {
      // Mock API call
      await new Promise(resolve => setTimeout(resolve, 500));
      set({ videos: mockVideos, isLoading: false });
    } catch (error) {
      set({ error: 'Failed to fetch videos', isLoading: false });
    }
  },

  likeVideo: (videoId: string) => {
    set(state => ({
      videos: state.videos.map(video => 
        video.id === videoId 
          ? { ...video, likes: video.likes + 1 }
          : video
      )
    }));
  },

  shareVideo: (videoId: string) => {
    set(state => ({
      videos: state.videos.map(video => 
        video.id === videoId 
          ? { ...video, shares: video.shares + 1 }
          : video
      )
    }));
  },

  uploadVideo: async (videoData: { title: string; description: string; file: File }) => {
    set({ isLoading: true, error: null });
    try {
      // Mock upload
      await new Promise(resolve => setTimeout(resolve, 2000));
      // In real app, this would upload to cloud storage and create video record
      set({ isLoading: false });
    } catch (error) {
      set({ error: 'Upload failed', isLoading: false });
    }
  },
}));