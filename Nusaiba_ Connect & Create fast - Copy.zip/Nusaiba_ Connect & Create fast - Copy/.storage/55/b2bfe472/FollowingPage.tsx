import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Users, 
  Play, 
  Heart, 
  MessageCircle, 
  Share2,
  Bell,
  BellOff,
  Radio
} from 'lucide-react';
import VideoCard from '@/components/Video/VideoCard';
import { useVideos } from '@/hooks/useVideos';

export default function FollowingPage() {
  const { videos } = useVideos();
  const [liveStreams, setLiveStreams] = useState([
    {
      id: '1',
      creator: 'Sarah Martinez',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b332c6a8?w=64&h=64&fit=crop&crop=face',
      title: 'Live Dance Session',
      viewers: 1250,
      thumbnail: 'https://images.unsplash.com/photo-1547153760-18fc86324498?w=300&h=200&fit=crop',
      isFollowing: true,
    },
    {
      id: '2',
      creator: 'David Chen',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=64&h=64&fit=crop&crop=face',
      title: 'Music Production Live',
      viewers: 890,
      thumbnail: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=300&h=200&fit=crop',
      isFollowing: true,
    },
  ]);

  const [followingUsers] = useState([
    {
      id: '1',
      name: 'Sarah Martinez',
      username: '@sarah_creates',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b332c6a8?w=40&h=40&fit=crop&crop=face',
      isLive: true,
      notifications: true,
    },
    {
      id: '2',
      name: 'David Chen',
      username: '@davidmusic',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
      isLive: true,
      notifications: true,
    },
    {
      id: '3',
      name: 'Maya Patel',
      username: '@maya_art',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face',
      isLive: false,
      notifications: false,
    },
  ]);

  // Filter videos from followed users only
  const followingVideos = videos.filter(video => 
    followingUsers.some(user => user.name === video.user.name)
  );

  const formatCount = (count: number) => {
    if (count < 1000) return count.toString();
    if (count < 1000000) return `${(count / 1000).toFixed(1)}K`;
    return `${(count / 1000000).toFixed(1)}M`;
  };

  const toggleNotifications = (userId: string) => {
    // Toggle notification settings for user
    console.log(`Toggling notifications for user ${userId}`);
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center">
          <Users className="h-8 w-8 mr-3 text-purple-600" />
          Following
        </h1>
        <p className="text-gray-600 mt-2">Content from people you follow</p>
      </div>

      {/* Live Streams Section */}
      {liveStreams.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center">
              <Radio className="h-5 w-5 mr-2 text-red-500" />
              Live Now
            </h2>
            <Button variant="outline" size="sm">View All</Button>
          </div>
          
          <div className="flex space-x-4 overflow-x-auto pb-4">
            {liveStreams.map((stream) => (
              <Card key={stream.id} className="flex-shrink-0 w-80 cursor-pointer hover:shadow-lg transition-shadow group">
                <CardContent className="p-0">
                  <div className="relative aspect-video bg-gray-100 rounded-t-lg overflow-hidden">
                    <img 
                      src={stream.thumbnail} 
                      alt={stream.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                      <Play className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    
                    {/* Live Badge */}
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-red-500 text-white text-xs animate-pulse">
                        <Radio className="h-3 w-3 mr-1" />
                        LIVE
                      </Badge>
                    </div>
                    
                    {/* Viewer Count */}
                    <div className="absolute top-3 right-3 bg-black/60 text-white px-2 py-1 rounded text-xs">
                      {formatCount(stream.viewers)} watching
                    </div>
                  </div>
                  
                  <div className="p-4">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={stream.avatar} alt={stream.creator} />
                        <AvatarFallback>{stream.creator.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-sm truncate">{stream.title}</h3>
                        <p className="text-xs text-gray-500">@{stream.creator}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Following Management */}
      <div className="mb-8">
        <h2 className="text-xl font-bold mb-4">Manage Following</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {followingUsers.map((user) => (
            <Card key={user.id}>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={user.avatar} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    {user.isLive && (
                      <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-sm truncate">{user.name}</h3>
                    <p className="text-xs text-gray-500">{user.username}</p>
                    {user.isLive && (
                      <Badge className="bg-red-100 text-red-800 text-xs mt-1">Live</Badge>
                    )}
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleNotifications(user.id)}
                    className={user.notifications ? 'text-purple-600' : 'text-gray-400'}
                  >
                    {user.notifications ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Following Feed */}
      <div>
        <h2 className="text-xl font-bold mb-6">Latest from Following</h2>
        {followingVideos.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {followingVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <Users className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">No content yet</h3>
            <p className="text-gray-500 mb-4">
              Follow some creators to see their latest content here
            </p>
            <Button className="bg-purple-600 hover:bg-purple-700">
              Discover Creators
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}