import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Settings, 
  Share2, 
  MoreHorizontal, 
  MapPin, 
  Link as LinkIcon, 
  Calendar,
  Play,
  Users,
  Heart,
  Bookmark,
  Grid3X3,
  Video,
  Radio
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import VideoCard from '@/components/Video/VideoCard';
import { useVideos } from '@/hooks/useVideos';

export default function UserProfile() {
  const { user } = useAuth();
  const { videos } = useVideos();
  const [activeTab, setActiveTab] = useState('posts');

  if (!user) return null;

  const userVideos = videos.filter(video => video.userId === user.id);
  const shortVideos = userVideos.filter(video => video.isShort);
  const longVideos = userVideos.filter(video => !video.isShort);

  const stats = [
    { label: 'Posts', value: userVideos.length },
    { label: 'Followers', value: user.followers },
    { label: 'Following', value: user.following },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          {/* Cover Photo */}
          <div className="relative h-48 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 rounded-lg mb-6 overflow-hidden">
            {user.coverPhoto ? (
              <img 
                src={user.coverPhoto} 
                alt="Cover" 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500"></div>
            )}
            
            {/* Profile Picture */}
            <div className="absolute -bottom-12 left-6">
              <Avatar className="w-24 h-24 border-4 border-white">
                <AvatarImage src={user.profilePicture} alt={user.name} />
                <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
            </div>
          </div>

          {/* Profile Info */}
          <div className="pt-12">
            <div className="flex items-start justify-between">
              <div className="space-y-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <h1 className="text-2xl font-bold">{user.name}</h1>
                    {user.isVerified && (
                      <Badge className="bg-blue-500 text-white">✓ Verified</Badge>
                    )}
                    {user.isPrivate && (
                      <Badge variant="secondary">Private</Badge>
                    )}
                  </div>
                  <p className="text-gray-600">@{user.username}</p>
                </div>

                {/* Bio */}
                {user.bio && (
                  <p className="text-gray-800 max-w-lg">{user.bio}</p>
                )}

                {/* Metadata */}
                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                  {user.location && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {user.location}
                    </div>
                  )}
                  {user.website && (
                    <div className="flex items-center">
                      <LinkIcon className="h-4 w-4 mr-1" />
                      <a href={user.website} className="text-blue-600 hover:underline" target="_blank" rel="noopener noreferrer">
                        Website
                      </a>
                    </div>
                  )}
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    Joined {new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center space-x-6">
                  {stats.map((stat) => (
                    <div key={stat.label} className="text-center">
                      <div className="text-xl font-bold">{stat.value.toLocaleString()}</div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
                <Button size="sm" className="bg-gradient-to-r from-purple-600 to-pink-600">
                  <Settings className="h-4 w-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Content Tabs */}
      <Card>
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="border-b px-6 py-4">
              <TabsList className="grid w-full max-w-md grid-cols-5">
                <TabsTrigger value="posts" className="flex items-center">
                  <Grid3X3 className="h-4 w-4 mr-1" />
                  Posts
                </TabsTrigger>
                <TabsTrigger value="videos" className="flex items-center">
                  <Video className="h-4 w-4 mr-1" />
                  Videos
                </TabsTrigger>
                <TabsTrigger value="shorts" className="flex items-center">
                  <Play className="h-4 w-4 mr-1" />
                  Shorts
                </TabsTrigger>
                <TabsTrigger value="live" className="flex items-center">
                  <Radio className="h-4 w-4 mr-1" />
                  Live
                </TabsTrigger>
                <TabsTrigger value="saved" className="flex items-center">
                  <Bookmark className="h-4 w-4 mr-1" />
                  Saved
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="p-6">
              <TabsContent value="posts" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {userVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
                {userVideos.length === 0 && (
                  <div className="text-center py-12">
                    <Grid3X3 className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No posts yet</h3>
                    <p className="text-gray-500">Share your first video to get started!</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="videos" className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {longVideos.map((video) => (
                    <VideoCard key={video.id} video={video} />
                  ))}
                </div>
                {longVideos.length === 0 && (
                  <div className="text-center py-12">
                    <Video className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No long videos yet</h3>
                    <p className="text-gray-500">Upload your first long-form video!</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="shorts" className="mt-0">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {shortVideos.map((video) => (
                    <VideoCard key={video.id} video={video} isShort={true} />
                  ))}
                </div>
                {shortVideos.length === 0 && (
                  <div className="text-center py-12">
                    <Play className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-semibold text-gray-600 mb-2">No shorts yet</h3>
                    <p className="text-gray-500">Create your first short video!</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="live" className="mt-0">
                <div className="text-center py-12">
                  <Radio className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No live streams yet</h3>
                  <p className="text-gray-500 mb-4">Connect with your audience in real-time!</p>
                  <Button className="bg-red-500 hover:bg-red-600 text-white">
                    <Radio className="h-4 w-4 mr-2" />
                    Start Live Stream
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="saved" className="mt-0">
                <div className="text-center py-12">
                  <Bookmark className="h-16 w-16 mx-auto text-gray-300 mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No saved content</h3>
                  <p className="text-gray-500">Bookmark videos to watch them later!</p>
                </div>
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}