export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  phone?: string;
  profilePicture?: string;
  coverPhoto?: string;
  bio?: string;
  website?: string;
  location?: string;
  gender: 'male' | 'female' | 'other';
  isVerified: boolean;
  isPrivate: boolean;
  followers: number;
  following: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Video {
  id: string;
  userId: string;
  user: User;
  title: string;
  description: string;
  url: string;
  thumbnailUrl: string;
  duration: number;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  isShort: boolean;
  hashtags: string[];
  isLive?: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Comment {
  id: string;
  userId: string;
  user: User;
  videoId: string;
  content: string;
  likes: number;
  replies: Comment[];
  createdAt: Date;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface VideoUpload {
  file: File;
  title: string;
  description: string;
  hashtags: string[];
  isShort: boolean;
  scheduled?: Date;
}

export interface LiveStream {
  id: string;
  userId: string;
  user: User;
  title: string;
  description: string;
  streamUrl: string;
  viewers: number;
  isActive: boolean;
  startedAt: Date;
}