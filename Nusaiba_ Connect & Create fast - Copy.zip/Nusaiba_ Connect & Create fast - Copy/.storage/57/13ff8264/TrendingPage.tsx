import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  Hash, 
  Play, 
  Heart, 
  MessageCircle, 
  Share2,
  Crown,
  Fire
} from 'lucide-react';

export default function TrendingPage() {
  const trendingVideos = [
    {
      id: '1',
      title: 'Epic Dance Battle Goes Viral!',
      thumbnail: 'https://images.unsplash.com/photo-1547153760-18fc86324498?w=400&h=600&fit=crop',
      creator: 'DanceMaster',
      views: 5200000,
      likes: 980000,
      comments: 45000,
      shares: 125000,
      hashtags: ['dance', 'viral', 'battle'],
      trendingScore: 98,
    },
    {
      id: '2',
      title: 'Mind-Blowing Magic Trick Explained',
      thumbnail: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop',
      creator: 'MagicPro',
      views: 3800000,
      likes: 720000,
      comments: 32000,
      shares: 89000,
      hashtags: ['magic', 'tutorial', 'mindblown'],
      trendingScore: 95,
    },
    {
      id: '3',
      title: 'Cooking Hack That Changes Everything',
      thumbnail: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=600&fit=crop',
      creator: 'ChefLife',
      views: 2900000,
      likes: 520000,
      comments: 28000,
      shares: 65000,
      hashtags: ['cooking', 'lifehack', 'food'],
      trendingScore: 89,
    },
    {
      id: '4',
      title: 'Pet Reaction to New Toy is Hilarious',
      thumbnail: 'https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&h=600&fit=crop',
      creator: 'PetLover',
      views: 2100000,
      likes: 410000,
      comments: 18000,
      shares: 42000,
      hashtags: ['pets', 'funny', 'reaction'],
      trendingScore: 86,
    },
  ];

  const formatCount = (count: number) => {
    if (count < 1000) return count.toString();
    if (count < 1000000) return `${(count / 1000).toFixed(1)}K`;
    return `${(count / 1000000).toFixed(1)}M`;
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center">
          <Fire className="h-8 w-8 mr-3 text-red-500" />
          Trending Now
        </h1>
        <p className="text-gray-600 mt-2">The hottest content on Nusaiba right now</p>
      </div>

      {/* Trending Videos Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {trendingVideos.map((video) => (
          <Card key={video.id} className="group cursor-pointer hover:shadow-lg transition-shadow">
            <CardContent className="p-0">
              <div className="relative aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden">
                <img 
                  src={video.thumbnail} 
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <Play className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
                <div className="absolute top-2 right-2">
                  <div className="flex items-center space-x-1 bg-red-500 text-white px-2 py-1 rounded text-xs">
                    <Fire className="h-3 w-3" />
                    <span>{video.trendingScore}</span>
                  </div>
                </div>
                <div className="absolute bottom-2 left-2 right-2">
                  <h4 className="text-white text-sm font-semibold line-clamp-2 mb-1">{video.title}</h4>
                  <div className="flex items-center justify-between text-white/80 text-xs">
                    <span>@{video.creator}</span>
                    <div className="flex items-center space-x-1">
                      <Heart className="h-3 w-3" />
                      <span>{formatCount(video.likes)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}