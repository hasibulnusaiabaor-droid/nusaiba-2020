import { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark,
  Send,
  X 
} from 'lucide-react';
import { Video, Comment } from '@/types';
import { useVideos } from '@/hooks/useVideos';

interface VideoPlayerProps {
  video: Video | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function VideoPlayer({ video, isOpen, onClose }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [comment, setComment] = useState('');
  const [comments, setComments] = useState<Comment[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { likeVideo, shareVideo } = useVideos();

  // Mock comments
  useEffect(() => {
    if (video) {
      setComments([
        {
          id: '1',
          userId: '2',
          user: {
            id: '2',
            username: 'viewer1',
            name: 'Amazing Viewer',
            email: 'viewer@example.com',
            profilePicture: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=32&h=32&fit=crop&crop=face',
            gender: 'male',
            isVerified: false,
            isPrivate: false,
            followers: 150,
            following: 89,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          videoId: video.id,
          content: 'This is incredible! 🔥',
          likes: 12,
          replies: [],
          createdAt: new Date(Date.now() - 3600000),
        },
        {
          id: '2',
          userId: '3',
          user: {
            id: '3',
            username: 'fan_account',
            name: 'Super Fan',
            email: 'fan@example.com',
            profilePicture: 'https://images.unsplash.com/photo-1494790108755-2616b332c6a8?w=32&h=32&fit=crop&crop=face',
            gender: 'female',
            isVerified: false,
            isPrivate: false,
            followers: 89,
            following: 234,
            createdAt: new Date(),
            updatedAt: new Date(),
          },
          videoId: video.id,
          content: 'Love your content! Keep it up! 💕',
          likes: 8,
          replies: [],
          createdAt: new Date(Date.now() - 1800000),
        },
      ]);
    }
  }, [video]);

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleLike = () => {
    if (video) {
      setIsLiked(!isLiked);
      if (!isLiked) {
        likeVideo(video.id);
      }
    }
  };

  const handleShare = () => {
    if (video) {
      shareVideo(video.id);
      navigator.share?.({
        title: video.title,
        text: video.description,
        url: window.location.href,
      }).catch(() => {
        // Fallback - copy to clipboard
        navigator.clipboard.writeText(window.location.href);
        alert('Link copied to clipboard!');
      });
    }
  };

  const sendComment = () => {
    if (comment.trim() && video) {
      const newComment: Comment = {
        id: Date.now().toString(),
        userId: 'current_user',
        user: {
          id: 'current_user',
          username: 'you',
          name: 'You',
          email: 'you@example.com',
          profilePicture: '',
          gender: 'other',
          isVerified: false,
          isPrivate: false,
          followers: 0,
          following: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
        videoId: video.id,
        content: comment,
        likes: 0,
        replies: [],
        createdAt: new Date(),
      };
      setComments([...comments, newComment]);
      setComment('');
    }
  };

  const formatCount = (count: number) => {
    if (count < 1000) return count.toString();
    if (count < 1000000) return `${(count / 1000).toFixed(1)}K`;
    return `${(count / 1000000).toFixed(1)}M`;
  };

  if (!video) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl w-full h-[90vh] p-0">
        <div className="flex h-full">
          {/* Video Section */}
          <div className="flex-1 bg-black relative">
            <video
              ref={videoRef}
              className="w-full h-full object-contain"
              poster={video.thumbnailUrl}
              onClick={togglePlay}
            >
              <source src={video.url} type="video/mp4" />
            </video>

            {/* Video Controls Overlay */}
            <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors duration-200 flex items-center justify-center group">
              <Button
                size="lg"
                variant="secondary"
                className="rounded-full w-16 h-16 bg-black/60 backdrop-blur-sm hover:bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                onClick={togglePlay}
              >
                {isPlaying ? <Pause className="h-8 w-8 text-white" /> : <Play className="h-8 w-8 text-white ml-1" />}
              </Button>
            </div>

            {/* Bottom Controls */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Button
                  size="sm"
                  variant="ghost"
                  className="text-white bg-black/20 backdrop-blur-sm hover:bg-black/40"
                  onClick={toggleMute}
                >
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
              </div>
              
              <Button
                size="sm"
                variant="ghost"
                className="text-white bg-black/20 backdrop-blur-sm hover:bg-black/40"
              >
                <Maximize className="h-4 w-4" />
              </Button>
            </div>

            {/* Close Button */}
            <Button
              size="sm"
              variant="ghost"
              className="absolute top-4 right-4 text-white bg-black/20 backdrop-blur-sm hover:bg-black/40"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Side Panel */}
          <div className="w-96 bg-white border-l flex flex-col">
            {/* Video Info */}
            <div className="p-4 border-b">
              <div className="flex items-start space-x-3 mb-4">
                <Avatar className="w-10 h-10">
                  <AvatarImage src={video.user.profilePicture} alt={video.user.name} />
                  <AvatarFallback>{video.user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-semibold">{video.user.username}</span>
                    {video.user.isVerified && (
                      <Badge className="bg-blue-500 text-white text-xs">✓</Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    {formatCount(video.user.followers)} followers
                  </p>
                </div>
                <Button size="sm" variant="outline">
                  Follow
                </Button>
              </div>

              <h2 className="font-semibold text-lg mb-2">{video.title}</h2>
              <p className="text-gray-600 text-sm mb-3">{video.description}</p>
              
              <div className="flex flex-wrap gap-1 mb-4">
                {video.hashtags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <span>{formatCount(video.views)} views</span>
                <span>•</span>
                <span>{new Date(video.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={isLiked ? 'text-red-500' : 'text-gray-500'}
                    onClick={handleLike}
                  >
                    <Heart className={`h-5 w-5 mr-1 ${isLiked ? 'fill-current' : ''}`} />
                    {formatCount(video.likes + (isLiked ? 1 : 0))}
                  </Button>
                  
                  <Button variant="ghost" size="sm" className="text-gray-500">
                    <MessageCircle className="h-5 w-5 mr-1" />
                    {formatCount(comments.length)}
                  </Button>

                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-gray-500"
                    onClick={handleShare}
                  >
                    <Share2 className="h-5 w-5" />
                  </Button>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  className={isBookmarked ? 'text-yellow-500' : 'text-gray-500'}
                  onClick={() => setIsBookmarked(!isBookmarked)}
                >
                  <Bookmark className={`h-5 w-5 ${isBookmarked ? 'fill-current' : ''}`} />
                </Button>
              </div>
            </div>

            {/* Comments */}
            <div className="flex-1 flex flex-col">
              <div className="p-4 border-b">
                <h3 className="font-semibold">Comments</h3>
              </div>
              
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start space-x-3">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={comment.user.profilePicture} alt={comment.user.name} />
                        <AvatarFallback className="text-xs">{comment.user.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="text-sm font-semibold">{comment.user.username}</span>
                          <span className="text-xs text-gray-500">
                            {new Date(comment.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-800">{comment.content}</p>
                        <div className="flex items-center space-x-3 mt-2">
                          <Button variant="ghost" size="sm" className="text-xs text-gray-500 p-0 h-auto">
                            <Heart className="h-3 w-3 mr-1" />
                            {comment.likes}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-xs text-gray-500 p-0 h-auto">
                            Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Comment Input */}
              <div className="p-4 border-t">
                <div className="flex space-x-2">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="text-xs">Y</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 flex space-x-2">
                    <Input
                      placeholder="Add a comment..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendComment()}
                      className="flex-1"
                    />
                    <Button size="sm" onClick={sendComment} disabled={!comment.trim()}>
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}